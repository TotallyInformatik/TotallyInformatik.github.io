import turtle as tr
import os
import random
import time

WN = tr.Screen()
WN.setup(300, 300)

WN.bgcolor("white")

WN.title("TicTacToe")
WN.addshape(os.path.expanduser("sprites/Player-Block.gif"))
# Gif for a block by the player

WN.addshape(os.path.expanduser("sprites/AI-Block.gif"))
# Gif for a block by the AI

WN.addshape(os.path.expanduser("sprites/NONE-Block.gif"))
# Gif for a block that isn't taken


# the Grid_blocks list contains all of the blocks in the game
Grid_blocks = []

# the rows go from right to left
# they include all of the blocks in the rows
row1 = []
row2 = []
row3 = []

# these are the blocks in the columns
# it goes from up to down
col1 = []
col2 = []
col3 = []

# we only have two diagonals
dia1 = []
""" 
(xoo)
(oxo)
(oox)

"""
dia2 = []
"""
(oox)
(oxo)
(xoo)

"""

# here are the corresponding lists but only the blocks by the player
player_grids = []
player_row1 = []
player_row2 = []
player_row3 = []
player_col1 = []
player_col2 = []
player_col3 = []
player_dia1 = []
player_dia2 = []

# this is the list with all of the lists of the player
player_all = (player_col1, player_col2, player_col3, player_row1, player_row2, player_row3, player_dia1, player_dia2)

# here are the corresponding lists but only the blocks by the AI
AI_grids = []
AI_row1 = []
AI_row2 = []
AI_row3 = []
AI_col1 = []
AI_col2 = []
AI_col3 = []
AI_dia1 = []
AI_dia2 = []

# this is the list with all of the lists of the AI
AI_all = (AI_col1, AI_col2, AI_col3, AI_row1, AI_row2, AI_row3, AI_dia1, AI_dia2)

# the turn is tracked via this string
turn = "player"

# this variable is to prevent the program from printing out the win message to often:
said = False


# this class is the template for all the blocks
# the state determines if the block has been taken by the player or the AI
# the column determines the column it is in
# the row determines the row it is in
# the tier helps the AI figure out which block it should take


class Block(tr.Turtle):
    def __init__(self, state, col, row, tier=None):
        tr.Turtle.__init__(self, shape=os.path.expanduser("sprites/NONE-Block.gif"))
        # this variable tracks is to whom the block goes to
        # LOWERCASE!!!
        self.state = state
        Grid_blocks.append(self)
        self.penup()
        self.color("black")
        self.speed(0)
        self.routes = []
        self.tier = tier
        self.row = row
        self.column = col

x = -70
y = 70

# this is the part that creates the Grid

# first row:
# same number as the index in the array ^
for col in range(3):
    Grid = Block("none", col, 0)
    row1.append(Grid)
    Grid.goto(x, y)
    x += 70

# resets the column and the coordinates
y -= 70
x = -70

# second row:
for col in range(3):
    Grid = Block("none", col, 1)
    row2.append(Grid)
    Grid.goto(x, y)
    x += 70

# resets again:
y -= 70
x = -70

# third row:
for col in range(3):
    Grid = Block("none", col, 2)
    row3.append(Grid)
    Grid.goto(x, y)
    x += 70


# this part adds the Blocks to the specific columns(arrays):
for Grd in Grid_blocks:
    if Grd.column == 0:
        col1.append(Grd)
    elif Grd.column == 1:
        col2.append(Grd)
    elif Grd.column == 2:
        col3.append(Grd)

# this part adds the Blocks to the specific diagonals:
# this is dia1

for index in range(3):
    for Grd in Grid_blocks:
        if Grd.column == index and Grd.row == index:
            dia1.append(Grd)


# this is dia2

index_col = 2
for index_row in range(3):
    for Grd in Grid_blocks:
        if Grd.column == index_col and Grd.row == index_row:
            dia2.append(Grd)
            index_col -= 1

# this tuple contains all list of the blocks
all_blocks = (col1, col2, col3, row1, row2, row3, dia1, dia2)

# these are the corners that are free
available_corners = [Grid_blocks[0], Grid_blocks[2], Grid_blocks[6], Grid_blocks[8]]


# functions


def append_chosen(grid_name):
    global AI_all

    for route in zip(AI_all, all_blocks):
        if grid_name in route[1]:
            route[0].append(grid_name)

    AI_all = (AI_col1, AI_col2, AI_col3, AI_row1, AI_row2, AI_row3, AI_dia1, AI_dia2)


def change(xc, yc):
    global turn
    global player_all
    if turn == "player" and not said:
        for grid in Grid_blocks:
            if grid.state == "none" and grid.xcor() - 25 < xc < grid.xcor() + 25 and grid.ycor() - 25 < yc < grid.ycor() + 25:
                grid.shape(os.path.expanduser("sprites/Player-Block.gif"))
                grid.state = "player"

                for route in zip(player_all, all_blocks):
                    if grid in route[1]:
                        route[0].append(grid)

                player_grids.append(grid)
                player_all = (
                    player_col1, player_col2, player_col3, player_row1, player_row2, player_row3, player_dia1,
                    player_dia2)

                turn = "AI"
                win_check()


def ai():
    global turn, case_checked, done
    # this variable will track if the AI has done sth. or not:
    done = False

    # for the "special case, we have a special variable that allows the AI to check the case only once,
    # as it'll be useless
    case_checked = False

    # checks for your turn first:
    if turn == "AI" and not said:
        
        time.sleep(1)

        if len(player_grids) >= 2:

            # checks "special case" first (to be found on phone):

            if (Grid_blocks[0].state == "player" and Grid_blocks[8].state == "player") or (
                    Grid_blocks[2].state == "player" and Grid_blocks[6].state == "player") and not case_checked and not done:
                chosen_block = random.choice([Grid_blocks[1], Grid_blocks[3], Grid_blocks[5], Grid_blocks[7]])
                while chosen_block.state != "none":
                    chosen_block = random.choice([Grid_blocks[1], Grid_blocks[3], Grid_blocks[5], Grid_blocks[7]])

                chosen_block.shape(os.path.expanduser("sprites/AI-Block.gif"))
                AI_grids.append(chosen_block)
                chosen_block.state = "AI"
                append_chosen(chosen_block)
                done = True
                case_checked = True

                # checks if any of its Blocks is in a row first:

            # this is the part where the AI checks if any row has two AI-blocks:
            for lst in zip(AI_all, all_blocks):
                if len(lst[0]) == 2 and not done:
                    for grd in lst[1]:
                        if grd in lst[1] and grd not in lst[0] and grd.state != "player":
                            grd.shape(os.path.expanduser("sprites/AI-Block.gif"))
                            AI_grids.append(grd)
                            grd.state = "AI"
                            append_chosen(grd)
                            done = True

            # first priority: defend:

            # this is the part where the AI checks if any row has two player-blocks:

            for lst in zip(player_all, all_blocks):
                if len(lst[0]) == 2 and not done:
                    for grd in lst[1]:
                        if grd in lst[1] and grd not in lst[0] and grd.state != "AI":
                            grd.shape(os.path.expanduser("sprites/AI-Block.gif"))
                            AI_grids.append(grd)
                            grd.state = "AI"
                            append_chosen(grd)
                            done = True

            # second priority: Attack:

            # first step: checks if a move has been made or not:

            if not done:

                attack_tier = 0
                defend_tier = 0
                all_grd_tiers = []

                for Grd in Grid_blocks:
                    if Grd.state == "none":
                        Grd.tier = 0
                        for route in all_blocks:
                            if Grd in route:
                                for Grid in route:
                                    if Grid != Grd and Grid.state == "AI":
                                        attack_tier += 1

                                    if Grid != Grd and Grid.state == "player":
                                        defend_tier += 1

                                if attack_tier == 1:
                                    Grd.tier += 1

                                if defend_tier == 1:
                                    Grd.tier += 1

                                attack_tier = 0
                                defend_tier = 0

                for Grd in Grid_blocks:
                    if Grd.state == "none":
                        all_grd_tiers.append(Grd.tier)

                opt_tier = max(all_grd_tiers)

                for Grd in Grid_blocks:
                    if Grd.state == "none" and Grd.tier == opt_tier and not done:
                        Grd.shape(os.path.expanduser("sprites/AI-Block.gif"))
                        AI_grids.append(Grd)
                        Grd.state = "AI"
                        append_chosen(Grd)
                        done = True

            # this last step is a step to prevent the AI from doing nothing. There are possibilities,
            # where all of the routes of the AI are discarded, thus leaving the AI to do nothing:

            if not done:
                # this solution is fairly simple:
                # the AI picks a random block, as if all routes are discarded, the outcome should be a tie anyway
                # so that's why the AI picks a random block

                # if the theory, that the outcome is going to be a tie is false, we can use the same tier/rank principle

                # this array contains all of the left blocks:
                available = []

                # stores all of the blocks/grids that haven't been claimed

                for block in Grid_blocks:
                    if block.state == "none":
                        available.append(block)

                # picks a random block out of the remaining blocks (available) if there is any block left:

                if len(available) != 0:
                    chosen = random.choice(available)

                    chosen.state = "AI"
                    chosen.shape(os.path.expanduser("sprites/AI-Block.gif"))
                    append_chosen(chosen)

        else:
            # tier 1 block (most valuable) (middle):

            if Grid_blocks[4].state == "none":
                Grid_blocks[4].shape(os.path.expanduser("sprites/AI-Block.gif"))
                AI_grids.append(Grid_blocks[4])
                AI_dia1.append(Grid_blocks[4])
                AI_dia2.append(Grid_blocks[4])
                AI_col2.append(Grid_blocks[4])
                AI_row2.append(Grid_blocks[4])
                Grid_blocks[4].state = "AI"

            # tier 2 block (2nd most valuable) (corners) :
            elif Grid_blocks[0].state or Grid_blocks[2].state or Grid_blocks[6].state or Grid_blocks[8].state == "none":

                # picks a random corner to place in and puts it into a variable:

                chosen_corner = available_corners[random.randint(0, len(available_corners)) - 1]

                chosen_corner.state = "AI"
                chosen_corner.shape(os.path.expanduser("sprites/AI-Block.gif"))
                AI_grids.append(chosen_corner)

                append_chosen(chosen_corner)

    turn = "player"
    win_check()


def win_check():
    global said, run
    """
    please change this function so that it checks for 3 in a row to see if ANYBODY has won and then checks which state
    it has, in order to determine WHO won
    """

    # checks if the player has won:

    for lst in player_all:
        if len(lst) == 3 and not said:

            pen.write("Player won", font=40)
            said = True
            run = False

    for lst in AI_all:
        if len(lst) == 3 and not said:

            pen.write("AI won", font=40)
            said = True
            run = False

    if run:
        grids_left = 9
        for grd in Grid_blocks:
            if grd.state != "none":
                grids_left -= 1

        if grids_left == 0 and not said:

            pen.write("It's a tie", font=40)
            said = True
            run = False


def available_corners_check():
    for corner in available_corners:
        if corner.state != "none":
            available_corners.remove(corner)


WN.listen()
WN.onclick(change, btn=1)

pen = tr.Turtle()
pen.penup()
pen.goto(-100, 100)
pen.write("Made by Rui Zhang", font=23)
pen.sety(pen.ycor() + 25)
pen.hideturtle()

run = True

while run:
    try: 
        WN.update()
        ai()
        available_corners_check()
    except:
        pass


time.sleep(1)
WN.bye()