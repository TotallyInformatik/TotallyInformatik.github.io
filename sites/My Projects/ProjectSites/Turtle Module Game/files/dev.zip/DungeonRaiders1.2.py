import turtle
import os
import time
import random


gameRun = True

while gameRun:

    """
    this is the Main menu:
    """

    # this variable checks for the choice that you have made

    not_chosen = True

    # this variable checks what you have chosen:

    choice = "none"

    MainWin = turtle.Screen()

    # clears everything

    MainWin.clearscreen()
    MainWin.bgpic(os.path.expanduser("sprites/MainMenu.gif"))
    MainWin.bgcolor("#808080")
    MainWin.setup(width=800, height=800)
    MainWin.tracer(0)
    MainWin.title("Game")

    cursor = turtle.Turtle()
    cursor.color("black")
    cursor.penup()
    cursor.goto(-120, 55)
    cursor.speed(0)
    cursor.shapesize(2, 2)


    def up():
        if not cursor.ycor() == 140:
            cursor.sety(cursor.ycor() + 85)


    def dn():
        if not cursor.ycor() == -30:
            cursor.sety(cursor.ycor() - 85)


    def choose():
        global not_chosen, choice
        if cursor.ycor() == 140:
            not_chosen = False
            # resets
            MainWin.bgpic(os.path.expanduser("sprites/BGpic.gif"))
            cursor.goto(10000, 10000)
            choice = "Tutorial"


    MainWin.listen()
    MainWin.onkeypress(up, "w")
    MainWin.onkeypress(dn, "s")
    MainWin.onkeypress(choose, "Return")

    while not_chosen:
        try:
            MainWin.update()
        except:
            gameRun = False

    # this is the Tutorial:

    if choice == "Tutorial":

        # entity class

        class Entities(turtle.Turtle):
            def __init__(self, Ent_shape, color, startx, starty, health):
                turtle.Turtle.__init__(self, shape=Ent_shape)

                # this is the animation speed

                self.speed(0)
                self.penup()
                self.fd(0)
                self.goto(startx, starty)
                self.color(color)
                self.health = health
                entities.append(self)


        class Shots(Entities):
            # Spd stands for speed
            def Spd(self):
                self.spd = random.randint(5, 8)
                shots.append(self)


        # right now making attack gui

        MainWin = turtle.Screen()
        MainWin.bgcolor("#808080")
        MainWin.setup(width=800, height=800)
        MainWin.tracer(0)
        MainWin.title("Tutorial")
        MainWin.addshape(os.path.expanduser("sprites/Player.gif"))
        MainWin.addshape(os.path.expanduser("sprites/Goblin.gif"))
        MainWin.addshape(os.path.expanduser("sprites/Spriteholder.gif"))
        MainWin.addshape(os.path.expanduser("sprites/Attack_Target.gif"))
        MainWin.addshape(os.path.expanduser("sprites/Wall.gif"))
        MainWin.addshape(os.path.expanduser("sprites/SpriteholderBlack.gif"))
        MainWin.addshape(os.path.expanduser("sprites/Healthbar.gif"))
        MainWin.addshape(os.path.expanduser("sprites/Elixirbar.gif"))

        # variables:

        mode = "Explore"
        # this following variable is an elixir bar: (kinda like your ultimate in Overwatch)
        elixir = 0
        GUI_made = False
        pen = turtle.Turtle()
        pen2 = turtle.Turtle()
        pen3 = turtle.Turtle()
        pen4 = turtle.Turtle()
        pen4.hideturtle()
        # this variable checks what kind of monster you are dealing with:
        enemy_type = "none"
        # this variable checks what you want to do when you fight:
        fight_choice = "none"
        # this variable checks if the timer of the attack is ready or not
        timer_ready = False
        # the following variable tells the program how many targets to make
        # PLEASE CHANGE WHEN MORE ENEMIES (HARDER ENEMIES) ARE MADE SO THAT IT CAN VARY
        target_speed = 100
        # the following var tracks the progress of the timer
        progress_timer = 0
        # target amount checks if the amount of targets have exceeded the given amount:
        # MAKE IT CHANGEABLE SOMETIME IN THE FUTURE
        # == 9 as a target is created at the start
        target_amount = 2
        # tracks the amount of targets
        progress_target = 0
        # an array of targets:
        targets = []
        # list of entities:
        entities = []
        # player and enemy take turns to attack, the following variable tells the game whose turn it is:
        turn = "Player"
        # variable to track whether the GoblinGUI() function has been made or not:
        GoblinGUI_made = False
        # this variable tells you how many shots the goblin fires:
        shot_amount = 0
        # this is the list containing all of the shots:
        shots = []
        # this variable tracks the amount of damage done:
        dealt_damage = 0
        # the next variable tracks the amount of targets that were hit:
        hit_targets = 0
        # the next variable sets the ypositon of the health_meter and the elixir_meter:
        health_m_ypos = 180
        elixir_m_ypos = 180

        # the next variable tracks how many items you have in your inventory:
        item_count = 0
        # the next variable tracks how far you have gone down the list of items in your inventory:
        pointer_count = 0

        # this variable allows the game to display the game once and stop it from doing it another time:

        # this variable keeps track of whether the tutorial has been made or not:
        tutorial_track = 0
        # this variable keeps the game from making too many of the tutorials:
        tutorial_made = False

        # variables to prevent the program from repeating the same lines

        beensaid = False
        beensaid2 = False
        beensaid3 = False

        # variable to check if its your first attack in the Tutorial to let you try the ultimate:
        first_atk = True
        # elixir made prevents the game from writing too many Ultimates
        elixir_made = False

        # Entities:

        player = Entities(os.path.expanduser("sprites/Player.gif"), "#000066", 0, 0, 100)
        # the following is a player entity made for the attack GUI for the Goblin, it is hidden at first:
        player_defend = Entities("arrow", "#cc3300", 0, 0, 100)
        player_defend.hideturtle()
        goblin = Entities(os.path.expanduser("sprites/Goblin.gif"), "#800000", 100, 0,
                          100)

        # makes a turtle that acts as a spriteholder of the faced enemy during attack mode:
        sprite = Entities(os.path.expanduser("sprites/Spriteholder.gif"), "white", 390,
                          150,
                          1)
        sprite.hideturtle()

        # functions:
        # function for making an Inventory:

        def inventory_delete():
            global fight_choice

            Inv_pen.clear()
            pen4.goto(225, -185)
            fight_choice = "none"


        def Inventory():
            global Inv_pen
            Inv_pen = turtle.Turtle()
            Inv_pen.color("white")
            Inv_pen.pencolor("white")
            Inv_pen.penup()
            Inv_pen.goto(-400, 300)
            Inv_pen.settiltangle(0)
            Inv_pen.pendown()
            Inv_pen.fillcolor("black")
            Inv_pen.begin_fill()
            Inv_pen.pensize(5)
            for i in range(2):
                Inv_pen.fd(800)
                Inv_pen.rt(90)
                Inv_pen.fd(600)
                Inv_pen.rt(90)
            Inv_pen.end_fill()
            Inv_pen.penup()
            Inv_pen.pendown()
            Inv_pen.hideturtle()
            if item_count != 0:
                pen4.goto(-350, 250)
                Inv_pen.goto(-330, -260)
                Inv_pen.write("Exit", font=("Avenir Next Condensed", 25))
            else:
                pen4.goto(-350, -240)
                Inv_pen.penup()
                Inv_pen.goto(-300, 100)
                Inv_pen.write("You don't have any items!", font=("Avenir Next Condensed", 30))


        # function for "Hurt that thingy"

        def Return():
            global fight_choice, timer_ready, timer, progress_timer, progress_target
            global tutorial_track, tutorial_made
            global run

            # this way it can't process if you are in an action:

            if tutorial_track == 13:
                run = False

            if fight_choice == "none" and mode == "Attack":

                # sets the attack choice by checking the y coordinates of the "cursor"

                if pen4.ycor() == -185:
                    fight_choice = "Hurt"
                    timer_ready = True

                if mode == "Attack" and fight_choice == "Hurt":
                    tutorial_track = 10
                    tutorial_made = False

                    # sets the variable values to 0 (resets)

                    progress_timer = 0
                    progress_target = 0

                    # spawn lots of entities, the entities have to be clicked by the mouse.
                    # a timer runs

                    Ftarget = Entities(os.path.expanduser("sprites/Attack_Target.gif"),
                                       "white", random.randint(215, 565), random.randint(-77, 375), 1)
                    targets.append(Ftarget)
                    timer_ready = True

                if pen4.ycor() == -255:
                    Inventory()
                    fight_choice = "Heal"

                elif pen4.ycor() == (-255 - 70):
                    fight_choice = "Extreme"

            if fight_choice == "Heal" and mode == "Attack":
                if not item_count == 0:
                    if pen4.ycor() == -240:
                        inventory_delete()
                elif item_count == 0:
                    if pen4.ycor() == -240:
                        time.sleep(1)
                        inventory_delete()


        # this function moves the timer

        def TimerMove():
            global timer, elixir, progress_timer, progress_target, timer_ready, fight_choice, mode, turn, dealt_damage, hit_targets, first_atk

            # the timer tells itself when to inform the game to make a new target depending on the variable target_speed
            if fight_choice == "Hurt":
                if timer_ready:
                    progress_timer += 1
                if progress_timer > target_speed and progress_target < target_amount:
                    target = Entities(os.path.expanduser("sprites/Attack_Target.gif"),
                                      "white", random.randint(215, 565), random.randint(-77, 375), 1)
                    targets.append(target)
                    progress_timer = 0
                    progress_target += 1

                # gives you some extra time:

                if progress_target == target_amount:
                    if progress_timer > target_speed:
                        timer_ready = False
                        if hit_targets == 3:
                            goblin.health -= 50
                            print("You inflicted 50 damage!")
                        else:
                            for i in range(hit_targets):
                                goblin.health -= 10
                                dealt_damage += 10
                            print("You inflicted {0} damage".format(dealt_damage))

                        print("The Goblin has {0} HP left".format(goblin.health))

                        if first_atk:
                            elixir = 100
                            first_atk = False

                        for i in range(2):  # has to be repeated for some reason...
                            for targ in targets:
                                targ.health = 0
                                targets.remove(targ)

                        turn = "Goblin"
                        if goblin.health == 0:
                            print("You killed the goblin!")
                            mode = "Explore"
                            turn = "Player"
                            fight_choice = "none"

                        hit_targets = 0
                        dealt_damage = 0
                        fight_choice = "none"


        def GUI():
            global GUI_made
            global mode
            global PenX
            global PenY
            global enemy_type
            global tutorial_track
            global tutorial_made
            if player.distance(goblin) < 30 and GUI_made == False:
                tutorial_track = 9
                tutorial_made = False
                mode = "Attack"
                attack_Win = turtle.Screen()
                attack_Win.setup(width=1200, height=800)
                player.setx(player.xcor() - 220)
                player_healthbar.setx(player_healthbar.xcor() - 200)
                player_elixirbar.setx(player_elixirbar.xcor() - 200)
                elixir_meter.setx(elixir_meter.xcor() - 200)
                health_meter.setx(health_meter.xcor() - 200)
                pen2.setx(pen2.xcor() - 200)
                pen3.setx(pen3.xcor() - 200)
                sprite.showturtle()

                goblin.setx(goblin.xcor() - 200)

                pen.clear()
                pen.penup()
                PenY = 110
                PenX = -590
                pen.goto(PenX, PenY)
                pen.showturtle()
                pen.pendown()
                pen.lt(90)
                for i in range(39):
                    pen.fd(220)
                    pen.penup()
                    PenX += 20
                    pen.goto(PenX, PenY)
                    pen.pendown()
                pen.rt(90)
                for i in range(12):
                    pen.fd(780)
                    pen.penup()
                    PenY -= 20
                    pen.goto(PenX, PenY)
                    pen.pendown()
                pen.hideturtle()

                # creates the actual GUI

                pen4.penup()
                pen4.setx(pen4.xcor() + 190)
                pen4.rt(90)
                pen4.fd(400)
                pen4.rt(180)
                pen4.begin_fill()
                pen4.pendown()
                pen4.fd(300)
                pen4.rt(90)
                pen4.fd(400)
                pen4.rt(90)
                pen4.fd(300)
                pen4.rt(90)
                pen4.fd(400)
                pen4.end_fill()
                pen4.color("white")
                pen4.pensize(5)
                pen4.rt(90)
                pen4.fd(300)
                pen4.rt(90)
                pen4.fd(400)
                pen4.rt(90)
                pen4.fd(300)
                pen4.rt(90)
                pen4.fd(400)

                # Writes sth.

                pen4.penup()
                pen4.goto(250, -200)
                pen4.color("white")
                pen4.write("Hurt that thing", font=("Avenir Next Condensed", 20))
                pen4.sety(pen4.ycor() - 70)
                pen4.write("Heal urself (haha ur a pussy)", font=("Avenir Next Condensed", 20))

                # pen4 then acts as if it were the cursor:

                pen4.goto(225, -185)
                pen4.showturtle()
                pen4.shapesize(1.5, 1.5)
                pen4.rt(180)

                # if the GUI already exist, the program hinders it from making another one:

                GUI_made = True


        def DeleteGUI():
            global GUI_made
            global tutorial_made, tutorial_track
            if goblin.health == 0 and GUI_made == True:

                # erases the drawn things

                pen4.clear()
                pen.clear()
                pen4.hideturtle()

                # hides the sprite holder

                sprite.hideturtle()

                # reformats the main windows and puts the objects back in place

                MainWin.setup(800, 800)
                pen2.goto(0, -260)
                pen3.goto(0, 260)
                player.goto(60, 0)
                player_healthbar.setx(player_healthbar.xcor() + 200)
                player_elixirbar.setx(player_elixirbar.xcor() + 200)
                health_meter.setx(health_meter.xcor() + 200)
                elixir_meter.setx(health_meter.xcor() + 200)

                # draws the original border

                pen.penup()

                PenY = 110
                PenX = -390
                pen.rt(180)
                pen.goto(PenX, PenY)
                pen.pendown()
                pen.pencolor("#666666")
                for i in range(11):
                    pen.fd(780)
                    pen.penup()
                    PenY -= 20
                    pen.goto(PenX, PenY)
                    pen.pendown()
                pen.rt(-90)
                for i in range(40):
                    pen.fd(220)
                    pen.penup()
                    PenX += 20
                    pen.goto(PenX, PenY)
                    pen.pendown()

                tutorial_made = False
                tutorial_track = 13

                GUI_made = False


        # the following function creates an attack GUI for the goblin:

        def GoblinGUI():
            global GoblinGUI_made
            global shots_amount
            global turn
            global fight_choice
            global tutorial_made
            global tutorial_track

            if turn == "Goblin" and GoblinGUI_made == False:

                # changes the spriteholder to black and makes a player:

                print("Goblin attacks!")
                shots_amount = 9
                tutorial_made = False
                tutorial_track = 11
                player_defend.showturtle()
                sprite.shape(os.path.expanduser("sprites/SpriteholderBlack.gif"))
                player_defend.goto(370, 0)
                player_defend.settiltangle(90)
                # the following is an Entity which resembles the shots that you have to dodge when the goblin attacks, is also hidden:
                # should be in entity section but it gets removed, so we have to respawn it

                goblin_shot = Shots("circle", "white", random.randint(220, 550), random.randint(810, 1100), 1)
                goblin_shot.Spd()
                goblin_shot.hideturtle()

                # makes copies of the shot:

                for amount in range(shots_amount):
                    # makes a copy of the shot but as an entity as it has to move too:

                    goblin_shot_copy = Shots("circle", "white", goblin_shot.xcor(), goblin_shot.ycor(), 1)
                    goblin_shot_copy.Spd()

                    goblin_shot.goto(random.randint(220, 550), random.randint(810, 1100))

                    GoblinGUI_made = True

            # moves the shots:

            for shot in shots:
                if not shot.ycor() < -80:
                    shot.sety(shot.ycor() - shot.spd)
                else:
                    shot.health -= 1

                # checks for collision with player_defend:
                if shot.distance(player_defend) < 15:
                    shot.health -= 1
                    player.health -= 20
                    print("The goblin hit you!")
                    print("The goblin dealt 20 damage!")
                    print("You have {0} hp left".format(player.health))

            # this part deletes the GUI if needed:
            if GoblinGUI_made and len(shots) == 0:
                tutorial_track = 12
                tutorial_made = False
                print("it\'s your turn!")
                player_defend.hideturtle()
                sprite.shape(os.path.expanduser("sprites/Spriteholder.gif"))
                GoblinGUI_made = False
                turn = "Player"
                fight_choice = "none"


        def a():
            if mode == "Explore":
                if not player.xcor() == -380:
                    player.settiltangle(180)
                    player.setx(player.xcor() - 20)
                    x = player.xcor()
                    y = player.ycor()
            if mode == "Attack" and turn == "Goblin" and not player_defend.xcor() < 210:
                player_defend.setx(player_defend.xcor() - 10)


        def d():
            if mode == "Explore":
                if not player.xcor() == 380:
                    player.settiltangle(0)
                    player.setx(player.xcor() + 20)
                    x = player.xcor()
                    y = player.ycor()
            if mode == "Attack" and turn == "Goblin" and not player_defend.xcor() > 570:
                player_defend.setx(player_defend.xcor() + 10)


        def w():
            global pen3
            global pen4
            if mode == "Explore":
                player.settiltangle(90)
                player.sety(player.ycor() + 20)
                x = player.xcor()
                y = player.ycor()
                if y > 100:
                    player.sety(player.ycor() - 20)
            elif mode == "Attack" and not pen4.ycor() == -185 and fight_choice == "none" and turn == "Player":
                pen4.sety(pen4.ycor() + 70)
            elif mode == "Attack" and fight_choice == "Heal" and not item_count == 0:
                if not pen4.ycor() == 250:
                    pen4.sety(pen4.ycor() + 70)


        def s():
            if mode == "Explore":
                player.settiltangle(-90)
                player.sety(player.ycor() - 20)
                x = player.xcor()
                y = player.ycor()
                if y < -100:
                    player.sety(player.ycor() + 20)
            elif mode == "Attack" and fight_choice == "none" and turn == "Player":
                if elixir == 0:
                    if not pen4.ycor() == -255:
                        pen4.sety(pen4.ycor() - 70)
                elif elixir == 100:
                    if not pen4.ycor() == -325:
                        pen4.sety(pen4.ycor() - 70)
            elif mode == "Attack" and fight_choice == "Heal" and not item_count == 0:
                if not pen4.ycor() == -240:
                    pen4.sety(pen4.ycor() - 70)


        # deletes all entities that have a health of 0
        def Delete():
            global run

            # runs through a filter that gets rid of all shots in the shots list first:

            for shot in shots:
                if shot.health <= 0:
                    shots.remove(shot)

            for ent in entities:
                if ent.health <= 0:
                    if ent == player:
                        pen4.goto(-300, -100)
                        pen4.color("Black")
                        pen4.write("Game Over", font=("Avenir Next Condensed", 100))
                        run = False
                    ent.goto(1000, 1000)
                    del ent


        # tutorial

        def leftclick(x, y):
            global tutorial_track
            global hit_targets
            global tutorial_made

            # checks if the cursor hit the target and makes it vanish if so

            if mode == "Explore":
                if tutorial_track < 8:
                    tutorial_track += 1
                    tutorial_made = False

            if mode == "Attack":
                for targ in targets:
                    if targ.xcor() - 25 < x < targ.xcor() + 25 and targ.ycor() - 25 < y < targ.ycor() + 25:
                        targets.remove(targ)
                        hit_targets += 1
                        targ.health = 0


        def bar_update():
            global health_m_ypos, elixir_m_ypos
            health_m_ypos = 180
            elixir_m_ypos = 180
            for i in range(player.health):
                health_m_ypos += 2
            health_meter.sety(health_m_ypos)
            for i in range(elixir):
                elixir_m_ypos += 2
            elixir_meter.sety(elixir_m_ypos)


        MainWin.listen()
        MainWin.onkeypress(a, "a")
        MainWin.onkeypress(s, "s")
        MainWin.onkeypress(d, "d")
        MainWin.onkeypress(w, "w")
        MainWin.onclick(leftclick, btn=1)
        MainWin.onkeypress(Return, "Return")

        # PENS
        """"""

        # these pens act as the border in the level:

        pen2.penup()
        pen2.shape(os.path.expanduser("sprites/Wall.gif"))
        pen2.color("#404040")
        pen2.goto(70, 410)
        pen2.pencolor("white")
        pen2.goto(0, -260)

        pen3.penup()
        pen3.goto(0, 260)
        pen3.shape(os.path.expanduser("sprites/Wall.gif"))
        pen3.color("#404040")
        pen3.pencolor("white")
        pen3.settiltangle(180)

        # we spawn the healthbar now so that the overlaping works:
        player_healthbar = Entities(os.path.expanduser("sprites/Healthbar.gif"), "white",
                                    0,
                                    0, 1)
        player_healthbar.goto(-320, 280)
        # creates a pen that is used to display how much health you have:
        health_meter = turtle.Turtle()
        health_meter.color("white")
        health_meter.penup()
        health_meter.goto(-300, health_m_ypos)
        health_meter.settiltangle(180)
        # this is the elixir bar:
        player_elixirbar = Entities(os.path.expanduser("sprites/Elixirbar.gif"), "white",
                                    0, 0, 1)
        player_elixirbar.goto(320, 280)
        # "cursor" for ellixir bar:
        elixir_meter = turtle.Turtle()
        elixir_meter.color("white")
        elixir_meter.penup()
        elixir_meter.goto(300, elixir_m_ypos)

        pen.penup()

        PenY = 90
        PenX = -390
        pen.goto(PenX, PenY)
        pen.pendown()
        pen.pencolor("#666666")
        for i in range(10):
            pen.fd(780)
            pen.penup()
            PenY -= 20
            pen.goto(PenX, PenY)
            pen.pendown()
        pen.rt(-90)
        for i in range(40):
            pen.fd(220)
            pen.penup()
            PenX += 20
            pen.goto(PenX, PenY)
            pen.pendown()

        # now the pen turns left and finishes the grid:

        pen.lt(90)
        pen.penup()
        pen.fd(20)
        pen.pendown()
        pen.fd(780)

        # then it hides itself:

        pen.hideturtle()
        """"""

        # this part displays a Tutorial:
        # this is the pen that does everything:

        tutPen = turtle.Turtle()
        tutPen.hideturtle()
        tutPen.penup()
        tutPen.color("white")


        def tutorial():

            global tutorial_made

            if tutorial_track == 0 and tutorial_made == False:
                goblin.goto(1000, 1000)
                tutPen.goto(-250, 250)
                tutPen.write("Hello bored Individual.", font=("Avenir Next Condensed", 40))
                tutPen.sety(tutPen.ycor() - 40)
                tutPen.write("Click to continue", font=("Avenir Next Condensed", 20))
                tutorial_made = True

            if tutorial_track == 1 and tutorial_made == False:
                tutPen.goto(-250, 200)
                tutPen.clear()
                tutPen.write("It has come to my attention \nthat you have somehow \ndiscovered this game.",
                             font=("Avenir Next Condensed", 40))
                tutPen.sety(tutPen.ycor() - 40)
                tutPen.write("Click to continue", font=("Avenir Next Condensed", 20))
                tutorial_made = True

            if tutorial_track == 2 and tutorial_made == False:
                tutPen.goto(-250, 250)
                tutPen.clear()
                tutPen.write("So let me explain to you everything:", font=("Avenir Next Condensed", 40))
                tutPen.sety(tutPen.ycor() - 40)
                tutPen.write("Click to continue", font=("Avenir Next Condensed", 20))
                tutorial_made = True

            if tutorial_track == 3 and tutorial_made == False:
                tutPen.goto(-250, 250)
                tutPen.clear()
                tutPen.write("Use WASD to move around and explore.", font=("Avenir Next Condensed", 40))
                tutPen.sety(tutPen.ycor() - 40)
                tutPen.write("Click to continue", font=("Avenir Next Condensed", 20))
                tutorial_made = True

            if tutorial_track == 4 and tutorial_made == False:
                tutPen.goto(-230, 230)
                tutPen.clear()
                tutPen.write("This is the healthbar,\n it will show you \n how much health you have.",
                             font=("Avenir Next Condensed", 40))
                tutPen.sety(tutPen.ycor() - 40)
                tutPen.write("Click to continue", font=("Avenir Next Condensed", 20))
                tutPen.showturtle()
                tutPen.goto(-230, 270)
                tutPen.settiltangle(180)
                tutPen.shapesize(2, 2)
                tutPen.pendown()
                tutPen.pensize(1)
                tutPen.goto(-270, 270)
                tutorial_made = True

            if tutorial_track == 5 and tutorial_made == False:
                tutPen.hideturtle()
                tutPen.penup()
                tutPen.goto(-250, 250)
                tutPen.clear()
                tutPen.write("The arrow on the side will indicate \n how much HP you have left",
                             font=("Avenir Next Condensed", 40))
                tutPen.sety(tutPen.ycor() - 40)
                tutPen.write("Click to continue", font=("Avenir Next Condensed", 20))
                tutorial_made = True

            if tutorial_track == 6 and tutorial_made == False:
                tutPen.goto(-230, 230)
                tutPen.clear()
                tutPen.write("This is the elixirbar,\n it will show you \n how much elixir you have.",
                             font=("Avenir Next Condensed", 40))
                tutPen.sety(tutPen.ycor() - 40)
                tutPen.write("Click to continue", font=("Avenir Next Condensed", 20))
                tutPen.showturtle()
                tutPen.penup()
                tutPen.goto(230, 270)
                tutPen.settiltangle(0)
                tutPen.shapesize(2, 2)
                tutPen.pendown()
                tutPen.pensize(1)
                tutPen.goto(270, 270)
                tutorial_made = True

            if tutorial_track == 7 and tutorial_made == False:
                tutPen.hideturtle()
                tutPen.penup()
                tutPen.goto(-250, 250)
                tutPen.clear()
                tutPen.write("The arrow on the side will indicate \n how much EX you have left",
                             font=("Avenir Next Condensed", 40))
                tutPen.sety(tutPen.ycor() - 40)
                tutPen.write("Click to continue", font=("Avenir Next Condensed", 20))
                tutorial_made = True

            if tutorial_track == 8 and tutorial_made == False:
                tutPen.goto(-250, 250)
                tutPen.clear()
                tutPen.write("Here you have a goblin. \nApproach it to fight.", font=("Avenir Next Condensed", 40))
                player.goto(0, 0)
                goblin.goto(100, 0)
                tutPen.sety(tutPen.ycor() - 40)
                tutPen.write("Approach to continue", font=("Avenir Next Condensed", 20))
                tutorial_made = True

            """
            The tutorial will consist of it tellng you what to do depending on how far you are in the fighting scene
            """

            if tutorial_track == 9 and tutorial_made == False:
                tutPen.goto(-250, 250)
                tutPen.clear()
                tutPen.setx(tutPen.xcor() - 200)
                tutPen.write("Choose the \"Attack\" option.", font=("Avenir Next Condensed", 40))
                player.goto(0, 0)
                goblin.goto(100, 0)
                tutPen.sety(tutPen.ycor() - 40)
                tutPen.write("Choose \"Attack\" to continue", font=("Avenir Next Condensed", 20))
                tutorial_made = True

            if tutorial_track == 10 and tutorial_made == False:
                tutPen.goto(-250, 250)
                tutPen.clear()
                tutPen.setx(tutPen.xcor() - 200)
                tutPen.sety(tutPen.ycor() - 50)
                tutPen.write(
                    "Attack by clicking at the targets! \nThe console will tell you \nhow much damage you\'ve done",
                    font=("Avenir Next Condensed", 40))
                player.goto(0, 0)
                goblin.goto(100, 0)
                tutPen.sety(tutPen.ycor() - 40)
                tutPen.write("Click the three targets to continue", font=("Avenir Next Condensed", 20))
                tutorial_made = True

            if tutorial_track == 11 and tutorial_made == False:
                tutPen.goto(-250, 250)
                tutPen.clear()
                tutPen.setx(tutPen.xcor() - 200)
                tutPen.write("Dodge the objects!", font=("Avenir Next Condensed", 40))
                player.goto(0, 0)
                goblin.goto(100, 0)
                tutPen.sety(tutPen.ycor() - 40)
                tutPen.write("Survive to continue", font=("Avenir Next Condensed", 20))
                tutorial_made = True

            if tutorial_track == 12 and tutorial_made == False:
                tutPen.goto(-250, 250)
                tutPen.clear()
                tutPen.setx(tutPen.xcor() - 200)
                tutPen.write("Repeat the steps to kill the enemy", font=("Avenir Next Condensed", 40))
                player.goto(0, 0)
                goblin.goto(100, 0)
                tutPen.sety(tutPen.ycor() - 40)
                tutPen.write("Eliminate the goblin to continue", font=("Avenir Next Condensed", 20))
                tutorial_made = True

            if tutorial_track == 13 and tutorial_made == False:
                tutPen.goto(-250, 250)
                tutPen.clear()
                tutPen.write("You finished the tutorial! \nPress enter to exit.", font=("Avenir Next Condensed", 40))
                player.goto(0, 0)
                goblin.goto(100, 0)
                tutPen.sety(tutPen.ycor() - 40)
                tutPen.write("Press enter to continue", font=("Avenir Next Condensed", 20))
                tutorial_made = True


        run = True

        while run:
            try:
                MainWin.update()

                # checks if player got close to the enemy:

                GUI()

                TimerMove()

                Delete()

                DeleteGUI()

                GoblinGUI()

                bar_update()

                tutorial()

                if elixir == 100 and not elixir_made:
                    pen4.goto(250, -200 - 70 - 70)
                    pen4.write("Use that one overpowered overwatch move", font=("Avenir Next Condensed", 20))
                    elixir_made = True
                    pen4.penup()
                    pen4.goto(225, -185)
                    pen4.showturtle()
                    pen4.shapesize(1.5, 1.5)
            except:
                gameRun = False





